//
//  Bearer.swift
//  RvBNB
//
//  Created by brian vilchez on 9/24/19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

import Foundation
struct Bearer: Codable {
    let token: String
}
